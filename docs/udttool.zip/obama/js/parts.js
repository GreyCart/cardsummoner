let parts = {
    'L': {
        'BC': {
            bottom: true,
            labor: 2
        },
        'SD': {
            bottom: true,
            labor: 0.5
        },
        'LCDC': {
            bottom: false,
            labor: 1
        },
        'KBB': {
            bottom: true,
            labor: 1
        },
        'KB': {
            bottom: true,
            labor: 0.5
        },
        'LCD': {
            bottom: false,
            labor: 1
        },
        'MB': {
            bottom: true,
            labor: 2
        },
        'HT': {
            bottom: true,
            labor: 3
        },
        'DC': {
            bottom: true,
            labor: 2
        },
        'RC': {
            bottom: true,
            labor: 1
        },
        'FN': {
            bottom: true,
            labor: 2
        },
        'RM': {
            bottom: true,
            labor: 0.5
        },
        'WC': {
            bottom: true,
            labor: 0.5
        },
        'AT': {
            bottom: false,
            labor: 1
        },
        'HC': {
            bottom: true,
            labor: 1
        },
        'MC': {
            bottom: true,
            labor: 1
        },
        'BT': {
            bottom: true,
            labor: 0.5
        },
        'HD': {
            bottom: true,
            labor: 1
        }
    },

    '5': {

    }
}