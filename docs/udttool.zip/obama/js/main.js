let topBGs = [
    'obama',
    'suicide',
    'froggy',
    'swagwalk',
    'vince',
    'hotdog'
];

let botBGs = [
    'nichijou',
    'patrick',
    'thonk',
    'darksouls'
];

let topBG = topBGs[Math.floor(Math.random() * topBGs.length)];
let midBG = botBGs[Math.floor(Math.random() * botBGs.length)];
let botBG = topBGs[Math.floor(Math.random() * topBGs.length)];


document.getElementById('headerContainer').style.backgroundImage = "url('./img/" + topBG + ".gif')";
document.getElementById('mainContainer').style.backgroundImage = "url('./img/" + midBG + ".gif')";
document.getElementById('footerContainer').style.backgroundImage = "url('./img/" + botBG + ".gif')";

let quoteBox    = document.getElementById('quoteBox');
let udtBox      = document.getElementById('udtBox');
let ocpsBox     = document.getElementById('ocpsBox');
let partsBox    = document.getElementById('partsBox');
let descBox     = document.getElementById('descBox');

let today = new Date();
today = today.toDateString();

function lockQuote() {
    quoteBox.readOnly = true;
}

function calcLabor(serial, p) {
    let topLabor = 0;
    let botLabor = 0;
    
    for(i=0; i!=p.length; i++) {
        if(parts[serial][p[i]].bottom) {
            botLabor += parts[serial][p[i]].labor;
        } else {
            topLabor += parts[serial][p[i]].labor;
        }
    }

    if(topLabor > 1) {
        topLabor = 1;
    }

    if(p.includes('HT')) {
        botLabor = 3;
    } else if(botLabor > 2) {
        botLabor = 2;
    }

    let totLabor = topLabor + botLabor;
    return totLabor;
}

function makeNote() {
    let quote = quoteBox.value;
    let udt = udtBox.value.split('-');
    let ocps = ocpsBox.value;
    let partsText = partsBox.value;
    let desc = descBox.value;

    let partsList = partsText.split('+');

    console.log(partsList);

    let message = 'Assessment completed '
                + today
                + '\n\n'
                + udt[1]
                + ' '
                + udt[0]
                + ' '
                + ocps
                + ' '
                + partsText
                + ' '
                + calcLabor(udt[0].substring(0,1), partsList)
                + ' '
                + desc
                + ' '
                + quote;
    
    let copied = document.getElementById('copied');
    copied.style.display = 'block';
    copied.value = message;
    copied.select();
    document.execCommand('copy');
    copied.style.display = 'none';
}